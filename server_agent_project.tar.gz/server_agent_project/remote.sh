wget https://raw.githubusercontent.com/thesunbg/server_agent_project/refs/heads/master/update.sh -O /tmp/update.sh &&
sudo bash /tmp/update.sh